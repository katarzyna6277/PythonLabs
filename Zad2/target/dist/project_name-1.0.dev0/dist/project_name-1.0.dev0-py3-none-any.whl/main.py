from lab1 import hello

def main():
    hello('World')


if '__main__' == __name__:
    main()
