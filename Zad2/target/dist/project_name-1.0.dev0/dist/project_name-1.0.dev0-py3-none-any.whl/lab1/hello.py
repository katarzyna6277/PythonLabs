def hello(name):
    print('Hello %s from %s and module %s' % (name, __package__, __name__))
