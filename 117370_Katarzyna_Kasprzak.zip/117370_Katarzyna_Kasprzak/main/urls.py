"""main URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from Tournaments import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import include
from django.contrib import admin
from django.urls import path

from Tournaments.views import NewLoginView, NewLogoutView, IndexView, player_tournament_view, tournament_view, \
    tournament_phase_view
from Tournaments.views.player_tournament_view import CreatePlayerTournamentView
from Tournaments.views.player_view import AllPlayersView, CreatePlayerView, DetailPlayerView
from Tournaments.views.register_view import SignUpView
from Tournaments.views.tournament_view import CreateTournamentView,   \
     AllTournamentView
urlpatterns = [
    path('', IndexView.as_view( ), name='index'),
    path('logout', NewLogoutView.as_view( ), name='logout'),
    path('logout', NewLogoutView.as_view( ), name='logout'),
    path('admin/', admin.site.urls),
    path('sign_up', SignUpView.as_view( ), name='sign_up'),
    path('tournaments', AllTournamentView.as_view(), name="all_tournament"),
    path('tournaments/add/', CreateTournamentView.as_view( ), name="tournament_add"),

    path('log_in', NewLoginView.as_view( ), name="tournament_delete"),

    path('players', AllPlayersView.as_view( ), name="all_players"),
    path('players/add/', CreatePlayerView.as_view( ), name="player_add"),
    path('players/<int:pk>/', DetailPlayerView.as_view( ), name="player_detail"),

    path('playertournaments/addplayer', CreatePlayerTournamentView.as_view( ), name="playertournament_add"),
    path('playertournaments/addplayers', player_tournament_view.add_player, name="add_relation_player_tournament"),
    path('tournaments/searching', tournament_view.find_tournament_view, name="tournament_search"),
    path('findtournamentresult/result', tournament_view.find_tournament_result, name="tournament_search_result2"),

    path('tournaments/phase/<int:pk>', tournament_phase_view.phase_list, name="tournament_results"),
    path('tournaments/phase_added/<int:pk>', tournament_phase_view.tournament_phase_add, name="phase_add"),
    path('tournaments/phase/add_player/<int:pk>', tournament_phase_view.tournament_phase_add_player_form, name="phase_add_player"),
    path('tournaments/phase/add_player/', tournament_phase_view.tournament_phase_add_player_adding, name="tournament_phase_add_player_adding"),

]
