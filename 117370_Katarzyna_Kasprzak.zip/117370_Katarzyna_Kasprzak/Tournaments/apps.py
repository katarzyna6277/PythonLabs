from django.apps import AppConfig


class ProjectPythonConfig(AppConfig):
    name = 'Tournaments'
