from django.shortcuts import render
from django.views.generic import ListView
from django.views.generic import CreateView
from django.utils import timezone
from django.urls import reverse_lazy
from django.contrib.messages.views import SuccessMessageMixin
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import models
from Tournaments import logger
from Tournaments.models import Tournament, PlayerTournament
from django.http import HttpResponse
from django.template import loader


class AllTournamentView(ListView):
    model = Tournament
    login_url = reverse_lazy('index')

    def get_context_data(self, **kwargs):
        logger.debug('AllTournamentView.get_context_data')

        tournaments = Tournament.objects.all()
        for x in range(0, tournaments.count( )):
            id_tournament = Tournament.objects.all( )[x].id
            new_current_participiants = PlayerTournament.objects.filter(tournament=x).count( )
            Tournament.objects.filter(id=id_tournament - 1).update(
                current_number_participants=new_current_participiants)

        context = super( ).get_context_data(**kwargs)
        context['now'] = timezone.now( )
        return context


class CreateTournamentView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    model = Tournament
    fields = ['id', 'name', 'max_number_participants', 'start_date']
    success_message = "Entry was created successfully"
    success_url = reverse_lazy('all_tournament')
    login_url = reverse_lazy('index')



def find_tournament_view(request):
    start_date = models.DateField( )
    end_date = models.DateField( )
    return render(request, 'find_tournament_by_date.html')


def find_tournament_result(request):
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    tournaments = Tournament.objects.filter(start_date__range=[start_date, end_date])
    template = loader.get_template('find_tournament_result_list.html')
    context = {
        'object_list': tournaments,
        'start_date': start_date,
        'end_date': end_date
    }
    return HttpResponse(template.render(context, request))
