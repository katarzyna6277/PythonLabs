from django.shortcuts import redirect
from django.views.generic import CreateView
from django.urls import reverse_lazy
from django.contrib.messages.views import SuccessMessageMixin
from django.contrib.auth.mixins import LoginRequiredMixin
from Tournaments.models import Tournament, PlayerTournament, Player


class CreatePlayerTournamentView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    model = PlayerTournament
    fields = ['tournament', 'player']
    success_message = "Entry was created successfully"
    success_url = reverse_lazy('all_tournament')
    login_url = reverse_lazy('index')


def add_player(request):
    tournament_id = request.POST.get('tournament')
    player_id = request.POST.get('player')
    current_participiants = PlayerTournament.objects.filter(tournament=tournament_id).count( )
    max_participiants = Tournament.objects.get(pk=tournament_id).max_number_participants
    player_tournament_presence = PlayerTournament.objects.filter(tournament=tournament_id, player=player_id).count( )
    tournament_object = Tournament.objects.get(pk=tournament_id)
    player_object = Player.objects.get(pk=player_id)
    if max_participiants > current_participiants and player_tournament_presence == 0:
        object = PlayerTournament.objects.create(tournament=tournament_object, player=player_object)

    return redirect('/')
